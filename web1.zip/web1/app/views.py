from distutils.log import info
from enum import Flag
from django.shortcuts import render,redirect
from .forms import *
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
# Create your views here.

def Register(request):
    form = BasicDetails()
    if request.method=='POST':
        form = BasicDetails(request.POST)
        if form.is_valid():
            form.save()
            User = form.cleaned_data.get("username")
            messages.success(request,"Account was created for "+ User)
            return redirect(WorkDetails)
        
    else:
        form = BasicDetails()
    return render(request,"home.html",{"form":form})

@login_required(login_url="LogInPage")
def WorkDetails(request):
    form = WorkDetailsForm()
    if request.method=='POST':
        form = WorkDetailsForm(request.POST,request.FILES)
        if form.is_valid():
            x = form.save(commit=False)
            x.name = request.user
            x.job_title = "hello"
            x.department = "IT"
            x.company_name = "MAXGEN"
            x.location = 'AHEMDABAD'
            x.save()
            return redirect('EducationalDetails')
    else:
        form = WorkDetailsForm()
    return render(request,"nework.html",{"form":form})


def LogInPage(request):

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect(WorkDetails)
            
        else:
            messages.info(request,"Username or Password is incorrect")
        
    return render(request,"login.html")

def LogOut(request):
    logout(request)
    return redirect(LogInPage)

@login_required(login_url="LogInPage")
def EducationalDetails(request):
    form = EducationalDetailsForm()
    if request.method=='POST':
        form = EducationalDetailsForm(request.POST , request.FILES)
        if form.is_valid():
            instance = form.save(commit=False)
            instance.name = request.user
            instance.save()
            return redirect(EducationalDetails)
    else:
        form = EducationalDetailsForm()

    return render(request,"edu.html",{"form":form})
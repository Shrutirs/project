from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class WorkDetails(models.Model):
    
        job_title =  models.CharField(max_length=200,null=True,blank=True)
        department = models.CharField(max_length=200,null=True,blank=True)
        company_name = models.CharField(max_length=200,null=True,blank=True)
        location = models.CharField(max_length=200,null=True,blank=True)
        upload_resume = models.FileField(upload_to="resume",default=None)
        name = models.ForeignKey(User, on_delete = models.DO_NOTHING, default=1)

        def __str__(self):
            return self.job_title



class EducationalDetails(models.Model):
    
        Institution_Name =  models.CharField(max_length=200)
        University_Name = models.CharField(max_length=200)
        Degree_Name = models.CharField(max_length=200)
        City = models.CharField(max_length=200)
        State = models.CharField(max_length=200)
        Upload_Marksheet = models.FileField(default=None)
        name = models.ForeignKey(User, on_delete = models.DO_NOTHING, default=1)

        def __str__(self):
            return self.job_title

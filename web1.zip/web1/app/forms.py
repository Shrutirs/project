from django import forms
from django.contrib.auth.forms import UserCreationForm #,AuthenticationForm
from django.contrib.auth.models import User
from .models import *
# from django.forms import ModelForm


class BasicDetails(UserCreationForm):
    class Meta:
        model = User
        fields =["first_name","last_name","email","username","password1","password2"]
         

class WorkDetailsForm(forms.ModelForm):
    class Meta:
        model = WorkDetails
        fields =["job_title","department","company_name","location","upload_resume"]

        # job_title =  forms.(max_length=200)
        # department = forms.CharField(max_length=200)
        # company_name = forms.CharField(max_length=200)
        # location = forms.CharField(max_length=200)
        # upload_resume = forms.FileField()
        

class EducationalDetailsForm(forms.ModelForm):
    class Meta:
        model = EducationalDetails
        fields = ["Institution_Name","University_Name","Degree_Name","City","Upload_Marksheet"]

        Institution_Name =  forms.CharField(max_length=200)
        University_Name = forms.CharField(max_length=200)
        Degree_Name = forms.CharField(max_length=200)
        City = forms.CharField(max_length=200)
        State = forms.CharField(max_length=200)
        Upload_Marksheet = forms.FileField()
